GLOBAL()
{
rm -rf /data/data/com.tencent.ig/app_appcache
rm -rf /data/data/com.tencent.ig/app_bugly
rm -rf /data/data/com.tencent.ig/app_crashrecord
rm -rf /data/data/com.tencent.ig/app_databases
rm -rf /data/data/com.tencent.ig/app_geolocation
rm -rf /data/data/com.tencent.ig/app_tbs
rm -rf /data/data/com.tencent.ig/app_textures
rm -rf /data/data/com.tencent.ig/app_webview
rm -rf /data/data/com.tencent.ig/app_webview_imsdk_inner_webview
rm -rf /data/data/com.tencent.ig/cache
rm -rf /data/data/com.tencent.ig/code_cache
rm -rf /data/data/com.tencent.ig/files
rm -rf /data/data/com.tencent.ig/no_backup
rm -rf /data/data/com.tencent.ig/databases
rm -f /data/cache/magisk.log
rm -f /data/cache/magisk.log.bak
}
KR()
{
rm -rf /data/data/com.pubg.krmobile/app_appcache
rm -rf /data/data/com.pubg.krmobile/app_bugly
rm -rf /data/data/com.pubg.krmobile/app_crashrecord
rm -rf /data/data/com.pubg.krmobile/app_databases
rm -rf /data/data/com.pubg.krmobile/app_geolocation
rm -rf /data/data/com.pubg.krmobile/app_tbs
rm -rf /data/data/com.pubg.krmobile/app_textures
rm -rf /data/data/com.pubg.krmobile/app_webview
rm -rf /data/data/com.pubg.krmobile/app_webview_imsdk_inner_webview
rm -rf /data/data/com.pubg.krmobile/cache
rm -rf /data/data/com.pubg.krmobile/code_cache
rm -rf /data/data/com.pubg.krmobile/files
rm -rf /data/data/com.pubg.krmobile/no_backup
rm -rf /data/data/com.pubg.krmobile/databases
rm -f /data/cache/magisk.log
rm -f /data/cache/magisk.log.bak
}
if [ -d "/storage/emulated/0/KSL13/GL" ];
then
am start -n com.tencent.ig/com.epicgames.ue4.SplashActivity
KSL13='com.tencent.ig'
while [ $(pidof $KSL13) ]
do
GLOBAL
((COUNT=$COUNT+10))
if [ ! $(pidof $KSL13) ]; then
break
fi
sleep 10
done
echo "Process Completed Cleaner Stopped"
fi
if [ -d "/storage/emulated/0/KSL13/KR" ];
then
am start -n com.pubg.krmobile/com.epicgames.ue4.SplashActivity
KSL13='com.pubg.krmobile'
while [ $(pidof $KSL13) ]
do
KR
((COUNT=$COUNT+10))
if [ ! $(pidof $KSL13) ]; then
break
fi
sleep 10
done
fi